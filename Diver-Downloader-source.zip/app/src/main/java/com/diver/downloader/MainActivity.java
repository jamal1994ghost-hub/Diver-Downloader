package com.diver.downloader;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.net.URI;
import java.util.Locale;

public final class MainActivity extends Activity {
    private EditText address;
    private TextView status;
    private ProgressBar progress;
    private Button action;
    private DiverEngine engine;
    private boolean running;
    private String pending;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        engine = new DiverEngine(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 24);
        root.setGravity(Gravity.TOP);
        TextView title = new TextView(this);
        title.setText("Diver Downloader"); title.setTextSize(27); root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Paste. Dive. Download."); root.addView(subtitle);
        address = new EditText(this);
        address.setSingleLine(); address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setHint(R.string.hint); root.addView(address);
        action = new Button(this); action.setText(R.string.download); root.addView(action);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); root.addView(progress, new LinearLayout.LayoutParams(-1, 24));
        status = new TextView(this); status.setText(R.string.status); status.setTextSize(16); root.addView(status);
        TextView limits = new TextView(this); limits.setText(R.string.limit); root.addView(limits);
        action.setOnClickListener(v -> { if (running) pause(); else start(); });
        receive(getIntent());
        String previous = getPreferences(MODE_PRIVATE).getString("pending", "");
        if (address.length() == 0 && !previous.isEmpty()) { address.setText(previous); status.setText(R.string.resume); }
        setContentView(root);
    }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); receive(intent); }
    private void receive(Intent intent) {
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null) address.setText(shared.trim());
        }
    }
    private void start() {
        String link = address.getText().toString().trim();
        try {
            URI uri = new URI(link);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) throw new Exception();
        } catch (Exception e) { status.setText(R.string.invalid); return; }
        File directory = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
        if (directory == null) { status.setText("Storage unavailable"); return; }
        String name = "download-" + Integer.toHexString(link.hashCode()) + ".bin";
        File target = new File(directory, name);
        if (target.exists()) { status.setText("Already downloaded: " + target.getName()); return; }
        pending = link;
        getPreferences(MODE_PRIVATE).edit().putString("pending", link).apply();
        running = true; action.setText(R.string.pause); status.setText("Connecting…");
        engine = new DiverEngine(this);
        engine.start(link, target, DiverEngine.Mode.BALANCED, new DiverEngine.Listener() {
            @Override public void progress(long bytes, long total) {
                runOnUiThread(() -> {
                    progress.setProgress((int) Math.min(100, bytes * 100 / total));
                    status.setText(String.format(Locale.getDefault(), "%d / %d MB", bytes / 1048576, total / 1048576));
                });
            }
            @Override public void finished(File file) {
                runOnUiThread(() -> {
                    running = false; action.setText(R.string.download);
                    status.setText(getString(R.string.saved) + ": " + file.getName());
                    getPreferences(MODE_PRIVATE).edit().remove("pending").apply();
                });
            }
            @Override public void failed(String reason) {
                runOnUiThread(() -> { running = false; action.setText(R.string.resume); status.setText(reason); });
            }
        });
    }
    private void pause() { engine.pause(); running = false; action.setText(R.string.resume); status.setText("Paused"); }
    @Override protected void onDestroy() { engine.pause(); super.onDestroy(); }
}
