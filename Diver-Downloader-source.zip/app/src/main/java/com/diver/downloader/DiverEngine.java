package com.diver.downloader;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.StatFs;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Direct HTTPS download engine. All callbacks arrive off the main thread. */
public final class DiverEngine {
    public interface Listener {
        void progress(long downloaded, long total);
        void finished(File file);
        void failed(String reason);
    }
    public enum Mode { ECO, BALANCED, TURBO }
    private static final int BUFFER = 32 * 1024;
    private final Context context;
    private final AtomicBoolean cancelled = new AtomicBoolean();
    private final ExecutorService coordinator = Executors.newSingleThreadExecutor();
    private volatile ExecutorService parts;

    public DiverEngine(Context context) { this.context = context.getApplicationContext(); }
    public void pause() {
        cancelled.set(true);
        ExecutorService active = parts;
        if (active != null) active.shutdownNow();
    }
    public void start(String address, File destination, Mode mode, Listener listener) {
        cancelled.set(false);
        coordinator.execute(() -> {
            try { download(address, destination, mode, listener); }
            catch (Exception e) { listener.failed(cancelled.get() ? "Paused" : safeError(e)); }
        });
    }
    private void download(String address, File target, Mode mode, Listener listener) throws Exception {
        URL url = new URL(address);
        if (!"https".equalsIgnoreCase(url.getProtocol())) throw new IOException("HTTPS required");
        HttpURLConnection probe = connection(url);
        probe.setRequestProperty("Range", "bytes=0-0");
        long length;
        String validator;
        boolean range;
        try {
            int code = probe.getResponseCode();
            if (code != 206 && code != 200) throw new IOException("HTTP " + code);
            String type = probe.getContentType();
            if (type != null && type.toLowerCase(java.util.Locale.ROOT).contains("text/html"))
                throw new IOException("Page URL is not a direct file");
            Matcher m = Pattern.compile("bytes 0-0/(\\d+)").matcher(value(probe.getHeaderField("Content-Range")));
            range = code == 206 && m.matches();
            length = range ? Long.parseLong(m.group(1)) : probe.getContentLengthLong();
            validator = value(probe.getHeaderField("ETag"));
            if (validator.isEmpty()) validator = value(probe.getHeaderField("Last-Modified"));
        } finally { probe.disconnect(); }
        if (length <= 0) throw new IOException("Unknown file size");
        File partial = new File(target.getPath() + ".part");
        File metadata = new File(target.getPath() + ".meta");
        String identity = address + "\n" + length + "\n" + validator;
        if (!metadata.exists() || !identity.equals(readText(metadata))) {
            if (partial.exists() && !partial.delete()) throw new IOException("Cannot reset partial file");
            writeText(metadata, identity);
        }
        StatFs stats = new StatFs(target.getParent());
        if (stats.getAvailableBytes() < Math.max(0, length - partial.length())) throw new IOException("Not enough storage");
        if (cancelled.get()) throw new IOException("Paused");
        // A resumable single stream is used for partially written files. Parallel parts start from zero.
        long start = range ? partial.length() : 0;
        if (!range && partial.exists() && !partial.delete()) throw new IOException("Cannot reset partial file");
        if (start > length) { partial.delete(); start = 0; }
        if (start == length) { finish(partial, target, metadata, listener); return; }
        int connections = start > 0 || !range || length < 8L * 1024 * 1024 ? 1 : chooseConnections(mode, length);
        if (connections == 1) {
            stream(url, partial, start, length - 1, length, range, validator, new AtomicLong(start), listener);
        } else {
            // Each task writes a disjoint byte range. On failure the next attempt safely restarts.
            try (RandomAccessFile file = new RandomAccessFile(partial, "rw")) { file.setLength(length); }
            final String expectedValidator = validator;
            AtomicLong count = new AtomicLong();
            parts = Executors.newFixedThreadPool(connections);
            List<Future<Void>> jobs = new ArrayList<>();
            long chunk = (length + connections - 1) / connections;
            for (int i = 0; i < connections; i++) {
                long from = i * chunk, to = Math.min(length - 1, from + chunk - 1);
                if (from > to) break;
                jobs.add(parts.submit((Callable<Void>) () -> { stream(url, partial, from, to, length, true, expectedValidator, count, listener); return null; }));
            }
            try { for (Future<Void> job : jobs) job.get(); }
            catch (Exception e) {
                cancelled.set(true); parts.shutdownNow();
                parts.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS);
                partial.delete(); throw e;
            }
            finally { parts.shutdownNow(); parts = null; }
            if (count.get() != length) {
                partial.delete(); throw new IOException("Incomplete parallel transfer");
            }
        }
        if (cancelled.get() || partial.length() != length) throw new IOException("Incomplete transfer");
        finish(partial, target, metadata, listener);
    }
    private void stream(URL url, File file, long from, long to, long total, boolean range,
                        String validator, AtomicLong count, Listener listener) throws Exception {
        for (int attempt = 0; attempt < 3; attempt++) {
            if (cancelled.get()) throw new IOException("Paused");
            long position = from;
            HttpURLConnection c = connection(url);
            if (range) {
                c.setRequestProperty("Range", "bytes=" + from + "-" + to);
                if (!validator.isEmpty()) c.setRequestProperty("If-Range", validator);
            }
            try {
                int code = c.getResponseCode();
                if (code != (range ? 206 : 200)) throw new IOException("HTTP " + code + ": range unavailable or source changed");
                if (range && !value(c.getHeaderField("Content-Range")).startsWith("bytes " + from + "-" + to + "/" + total))
                    throw new IOException("Invalid Content-Range");
                try (InputStream input = c.getInputStream(); RandomAccessFile output = new RandomAccessFile(file, "rw")) {
                    output.seek(from);
                    byte[] buffer = new byte[BUFFER];
                    int n;
                    while ((n = input.read(buffer)) != -1) {
                        if (cancelled.get()) throw new IOException("Paused");
                        if (position + n > to + 1) throw new IOException("Response exceeds range");
                        output.write(buffer, 0, n);
                        position += n;
                        listener.progress(count.addAndGet(n), total);
                    }
                }
                if (position != to + 1) throw new IOException("Short response");
                return;
            } catch (IOException e) {
                count.addAndGet(from - position);
                if (cancelled.get() || attempt == 2 || e.getMessage().contains("range") || e.getMessage().contains("HTTP 4")) throw e;
                Thread.sleep((attempt + 1) * 800L);
            } finally { c.disconnect(); }
        }
    }
    private int chooseConnections(Mode mode, long bytes) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkCapabilities n = cm.getNetworkCapabilities(cm.getActiveNetwork());
        int speed = n == null ? 0 : n.getLinkDownstreamBandwidthKbps();
        int cap = mode == Mode.ECO ? 2 : mode == Mode.TURBO ? 8 : 4;
        int recommended = speed < 3000 ? 2 : speed < 15000 ? 4 : 8;
        return Math.max(1, Math.min(Math.min(cap, recommended), (int) Math.max(1, bytes / (4L * 1024 * 1024))));
    }
    private static HttpURLConnection connection(URL url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(true);
        return c;
    }
    private static void finish(File partial, File target, File metadata, Listener listener) throws IOException {
        if (target.exists() || !partial.renameTo(target)) throw new IOException("Cannot save completed file");
        metadata.delete(); listener.finished(target);
    }
    private static String value(String s) { return s == null ? "" : s; }
    private static String safeError(Exception e) { return e.getMessage() == null ? "Download failed" : e.getMessage(); }
    private static String readText(File file) throws IOException { return new String(java.nio.file.Files.readAllBytes(file.toPath()), java.nio.charset.StandardCharsets.UTF_8); }
    private static void writeText(File file, String text) throws IOException { java.nio.file.Files.write(file.toPath(), text.getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
}
